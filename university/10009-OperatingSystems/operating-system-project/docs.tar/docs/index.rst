.. include:: ../README.rst
.. include:: tut.rst
.. include:: notes.rst


.. toctree::
    :hidden:
    :glob:

    *
